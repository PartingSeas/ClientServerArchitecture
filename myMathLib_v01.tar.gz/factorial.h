/*
 * Name			: Manzel Gomez
 * This File	: factorial.h
 *
 * Description	: C function headers of factorial functions.
 * 
*/

#ifndef FACTORIAL_H
#define FACTORIAL_H

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

unsigned long factorial(unsigned int n, char iOrR);
unsigned long factorialIterative(unsigned int n);
unsigned long factorialRecursive(unsigned int n);

#endif	// FACTORIAL_H

