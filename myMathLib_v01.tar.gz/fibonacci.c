/*
 * Name			: Manzel Gomez
 * This File	: fibonacci.c
 *
 * Description	: C functions to find n th Fibonacci number (for n >= 0).
 * 
 * This file has two implementations of the fibonacci - one iterative and one recursive.
*/

#include "fibonacci.h"


unsigned long fibonacci(unsigned int n, char iOrR) {
	if(toupper(iOrR) == 'I') {
		return fibonacciIterative(n);
	}
	else if(toupper(iOrR) == 'R') {
		return fibonacciRecursive(n);
	}
	else {
		fprintf(stderr, "Valid values for the second parameter, iOrR, are either i or r\n");
		exit(2);
	}
} // end of unsigned long fibonacci(unsigned int n, char iOrR)



unsigned long fibonacciIterative(unsigned int n) {
	#ifdef DEBUG
	printf("\tentering fibonacciIterative(%u)\n", n);
	#endif
	unsigned long int fbncPrev2 = 0;	// fibonacci-prev2
	unsigned long int fbncPrev1 = 1;	// fibonacci-prev1
	unsigned long int fbnc;				// fibonacci-current

	if (n == 0) {
		return fbncPrev2;
	}

	if (n == 1) {
		return fbncPrev1;
	}

	// we are here because n != 0 and n != 1 (i.e. n >= 2 as it is unsigned)
	for (int i = 2; i < n; i++) {
		fbnc = fbncPrev2 + fbncPrev1;
		#ifdef DEBUG
		printf("%d ", fbnc);
		printf("\tfbnc[%d] = %lu\n", i, fbnc);
		#endif
		fbncPrev2 = fbncPrev1;
		fbncPrev1 = fbnc;
	}

	#ifdef DEBUG
	printf("\texiting fibonacciIterative(%u)\n", n);
	#endif
	return fbnc;
} // end of unsigned long fibonacciIterative(unsigned int n)



unsigned long fibonacciRecursive(unsigned int n) {
	#ifdef DEBUG
	printf("\tentering fibonacciRecursive(%u)\n", n);
	#endif

	unsigned long fbnc;
	if(n == 0) {
		#ifdef DEBUG
		printf("\texiting fibonacciRecursive(%u) base case\n", n);
		#endif
		return fbnc = 0;
	}
	else if(n == 1) {
		#ifdef DEBUG
		printf("\texiting fibonacciRecursive(%u) base case\n", n);
		#endif
		return fbnc = 1;
	}
	else {
		#ifdef DEBUG
		printf("\texiting fibonacciRecursive(%u)\n", n);
		#endif
		return fbnc = fibonacciRecursive(n-2) + fibonacciRecursive(n-1);
	}

} // end of unsigned long fibonacciRecursive(unsigned int n)

