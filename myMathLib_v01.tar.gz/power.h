/*
 * Name			: Manzel Gomez
 * This File	: power.h
 *
 * Description	: C header file for the power function
 * 
 * NOTE: there is no error checking for any kind of overflows
 * 
*/

#ifndef POWER_H
#define POWER_H

#include <stdio.h>

long long power(int a, unsigned int n);

#endif	// POWER_H

