/*
 * Name			: Manzel Gomez
 * This File	: mathProject.h
 *
 * Description	: C header file for the main program mathTester
 * 
*/

#ifndef MATHPROJECT_H
#define MATHPROJECT_H

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

#include "factorial.h"
#include "fibonacci.h"
#include "power.h"

#endif	// MATHPROJECT_H

