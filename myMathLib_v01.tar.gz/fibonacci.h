/*
 * Name			: Manzel Gomez
 * This File	: fibonacci.h
 *
 * Description	: C function headers of fibonacci functions.
 * 
*/

#ifndef FIBONACCI_H
#define FIBONACCI_H

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

unsigned long fibonacci(unsigned int n, char iOrR);
unsigned long fibonacciIterative(unsigned int n);
unsigned long fibonacciRecursive(unsigned int n);

#endif	// FIBONACCI_H

