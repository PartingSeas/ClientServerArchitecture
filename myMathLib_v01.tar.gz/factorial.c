/*
 * Name			: Manzel Gomez
 * This File	: factorial.c
 *
 * Description	: C functions to find factorial of a given number.
 * 
 * This file has two implementations of the factorial function - one iterative
 * and one recursive.
*/

#include "factorial.h"



unsigned long factorial(unsigned int n, char iOrR) {
	if(toupper(iOrR) == 'I') {
		return factorialIterative(n);
	}
	else if(toupper(iOrR) == 'R') {
		return factorialRecursive(n);
	}
	else {
		fprintf(stderr, "Valid values for the second parameter, iOrR, are either i or r\n");
		exit(2);
	}
} // end of unsigned long factorial(unsigned int n, char iOrR)



unsigned long factorialIterative(unsigned int n) {
	#ifdef DEBUG
	printf("\tentering factorialIterative(%u)\n", n);
	#endif
	unsigned long fact = 1;						// this takes care of the case n = 0

	for(unsigned int i = 1; i <= n; i ++) {
		fact = fact * i;						// iterative definition !n = 1*2*3 . . . *n
	}

	#ifdef DEBUG
	printf("\texiting factorialIterative(%u)\n", n);
	#endif
	return fact;
} // end of unsigned long factorialIterative(unsigned int n)



unsigned long factorialRecursive(unsigned int n) {
	#ifdef DEBUG
	printf("\tentering factorialRecursive(%u)\n", n);
	#endif

	if (n == 0 || n == 1) {
		#ifdef DEBUG
		printf("\texiting factorialRecursive(%u)\n", n);
		#endif
		return 1;								// the base cases
	}
	else {
		return n * factorialRecursive(n-1);		// the recursive definition
	}

} // end of unsigned long factorialRecursive(unsigned int n)

