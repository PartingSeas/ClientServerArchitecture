/*
 * Name			: Manzel Gomez
 * This File	: mathTester.c
 *
 * Description	: C Program to test different math functions from our math library
 * 
*/

#include "mathProject.h"

int main(int argc, char *argv[]) {
	unsigned int n;
	printf("enter an integer value :");
	scanf("%d", &n);
	printf("You entered %d\n", n);

	unsigned long fibo = fibonacci(n, 'r');
	printf("F[%d], %dth Fibonacci number, is %lu\n", n, n, fibo);

	unsigned long fact = factorial(n, 'r');
	printf("Factorial of %d is %lu\n", n, fact);

	long long pwr = power(3, n);
	printf("%d raised to the %uth power is %lld\n", 3, n, pwr);

	return 0;
} // end of int main(int argc, char *argv[]) 

