/*
 * Name			: Manzel Gomez
 * This File	: power.c
 *
 * Description	: C function to compute integral power of an integer
 * NOTE: there is no error checking for any kind of overflows
 * 
*/


#include "power.h"


long long power(int a, unsigned int n) {
	long long result;
	if(n == 0) {
		return result = 1;
	}
	else {
		return result = a * power(a, n-1);
	}

} // end of long long power(int a, unsigned int n)

